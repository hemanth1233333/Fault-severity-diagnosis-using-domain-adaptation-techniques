import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import numpy as np
import  pandas as pd
import  load
import corelation

class FRAN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(FRAN, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, output_size)
        )

    def forward(self, x):
        return self.encoder(x)

def train_fran(fran_model, dataloader_source, dataloader_target, num_epochs=10, learning_rate=0.001):
    criterion = nn.MSELoss()
    optimizer = optim.Adam(fran_model.parameters(), lr=learning_rate)
    for epoch in range(num_epochs):
        for source_data, target_data in zip(dataloader_source, dataloader_target):
            source_inputs, _ = source_data
            target_inputs, _ = target_data
            source_inputs = torch.FloatTensor(source_inputs)
            target_inputs = torch.FloatTensor(target_inputs)
            source_features = fran_model(source_inputs)
            target_features = fran_model(target_inputs)


            loss = criterion(source_features, target_features)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {loss.item()}')

def getAcuracy(sx,sy,tx,ty):
    source_data=sx
    source_labels=sy
    target_data=tx
    target_labels = ty
    scaler = StandardScaler()
    source_data = scaler.fit_transform(source_data)
    target_data = scaler.transform(target_data)

    source_train_data, source_test_data, sytrain, sytest = train_test_split(source_data, source_labels, test_size=0.2)
    target_train_data, target_test_data, tytrain, tytest = train_test_split(target_data, target_labels, test_size=0.2)

    source_train_tensor = torch.FloatTensor(source_train_data)
    target_train_tensor = torch.FloatTensor(target_train_data)
    source_test_tensor = torch.FloatTensor(source_test_data)
    target_test_tensor = torch.FloatTensor(target_test_data)

    source_dataset = TensorDataset(source_train_tensor, source_train_tensor)  # In unsupervised, labels are not used
    target_dataset = TensorDataset(target_train_tensor, target_train_tensor)
    source_dataloader = DataLoader(source_dataset, batch_size=32, shuffle=True)
    target_dataloader = DataLoader(target_dataset, batch_size=32, shuffle=True)

    input_size = source_train_data.shape[1]
    hidden_size = 600
    output_size = source_train_data.shape[1]

    fran_model = FRAN(input_size, hidden_size, output_size)

    train_fran(fran_model, source_dataloader, target_dataloader, num_epochs=10)
    with torch.no_grad():
        fran_model.eval()
        target_test_features = fran_model(target_test_tensor)
        threshold = 0.5
        reconstruction_errors = torch.mean(torch.abs(target_test_tensor - target_test_features), dim=1)
        print(reconstruction_errors)
        predictions = (reconstruction_errors > threshold).float()
        print(predictions)
        true_labels = torch.FloatTensor(tytest.values)
        accuracy = torch.sum(predictions == true_labels).item() / len(true_labels)
        print(f"Accuracy-like Metric: {accuracy}")
        tp = torch.sum((predictions == 1) & (true_labels == 1)).item()
        fp = torch.sum((predictions == 1) & (true_labels == 0)).item()
        fn = torch.sum((predictions == 0) & (true_labels == 1)).item()
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        f1_score = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
        print(f"Precision: {precision}, Recall: {recall}, F1 Score: {f1_score}")
        return  accuracy


acuotpt=[]
for x in range(0,8):
    t=[]
    for y in range(0,8):
        t.append(0)
    acuotpt.append(t)

for x in range(0,8):
    sourcedata=None
    if x==0:
     sourcedata=load.dfde007
    elif x==1:
        sourcedata = load.dfde014
    elif x == 2:
        sourcedata = load.dfde021
    elif x == 3:
        sourcedata = load.dffe007
    elif x == 4:
        sourcedata = load.dffe014
    elif x == 5:
        sourcedata = load.dffe021
    elif x == 6:
        sourcedata = load.dfde
    elif x == 7:
        sourcedata = load.dffe
    sX = sourcedata.drop(1200, axis=1)

    sy = sourcedata[1200]
    for y in range(0, 8):
        targetdata=None
        if x == 0:
            targetdata = load.dfde007
        elif x == 1:
            targetdata = load.dfde014
        elif x == 2:
            targetdata = load.dfde021
        elif x == 3:
            targetdata = load.dffe007
        elif x == 4:
            targetdata = load.dffe014
        elif x == 5:
            targetdata = load.dffe021
        elif x == 6:
            targetdata = load.dfde
        elif x == 7:
            targetdata = load.dffe

        tX = targetdata.drop(1200, axis=1)

        ty = targetdata[1200]
        ty=pd.Series(ty)
        vl=getAcuracy(sX,sy,tX,ty)
        vl*=100
        acuotpt[x][y]=vl


print(acuotpt)
corelation.matrix(acuotpt)