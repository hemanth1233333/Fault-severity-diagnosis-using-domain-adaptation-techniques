import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

def matrix(data):
    dataframe = pd.DataFrame(data, columns=['DE007', 'DE014', 'DE021', 'FE007', 'FE014','FE021','DE','FE'])
    dataframe=dataframe.set_index(pd.Index(['DE007', 'DE014', 'DE021', 'FE007', 'FE014','FE021','DE','FE']))
    print(dataframe)
    plt.figure(figsize=(8, 6))
    sns.heatmap(dataframe, annot=True, cmap='coolwarm', fmt='.2f', linewidths=0.5)
    plt.title('Correlation Matrix Heatmap')
    plt.show()






