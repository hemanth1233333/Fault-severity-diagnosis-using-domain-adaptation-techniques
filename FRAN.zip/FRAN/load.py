from numpy import load
import  numpy as np
import pandas as pd
de = load("C:\Users\mahit\OneDrive\Desktop\Final_year_project\Data\CWRU_DE.npy", allow_pickle=True)
de007 = load(""C:\Users\mahit\OneDrive\Desktop\Final_year_project\Data\CWRU_DE007.npy", allow_pickle=True)
de014 = load("C:\Users\mahit\OneDrive\Desktop\Final_year_project\Data\CWRU_DE014.npy", allow_pickle=True)
de021 = load("C:\Users\mahit\OneDrive\Desktop\Final_year_project\Data\CWRU_DE021.npy", allow_pickle=True)
fe = load("C:\Users\mahit\OneDrive\Desktop\Final_year_project\Data\CWRU_FE.npy", allow_pickle=True)
fe007 = load("C:\Users\mahit\OneDrive\Desktop\Final_year_project\Data\CWRU_FE007.npy", allow_pickle=True)
fe014 = load("C:\Users\mahit\OneDrive\Desktop\Final_year_project\Data\CWRU_FE014.npy", allow_pickle=True)
fe021 = load("C:\Users\mahit\OneDrive\Desktop\Final_year_project\Data\CWRU_FE021.npy", allow_pickle=True)

df=pd.DataFrame(de.item()['IR'].T[0]).transpose()
df['label']=1
sm=pd.DataFrame(de.item()['OR'].T[0]).transpose()
sm['label']=1
sm1=pd.DataFrame(de.item()['B'].T[0]).transpose()
sm1['label']=1
sm2=pd.DataFrame(de.item()['Normal'].T[0]).transpose()
sm2['label']=0
a1=sm.values
a3=sm1.values
a4=sm2.values
a2=df.values
array=np.append(a1,a2, axis=0)
array=np.append(array,a3, axis=0)
array=np.append(array,a4, axis=0)
dfde=pd.DataFrame(array)
print(dfde)
df=pd.DataFrame(de007.item()['IR'].T[0]).transpose()
df['label']=1
sm=pd.DataFrame(de007.item()['OR'].T[0]).transpose()
sm['label']=1
sm1=pd.DataFrame(de007.item()['B'].T[0]).transpose()
sm1['label']=1
sm2=pd.DataFrame(de007.item()['Normal'].T[0]).transpose()
sm2['label']=0
a1=sm.values
a3=sm1.values
a4=sm2.values
a2=df.values
array=np.append(a1,a2, axis=0)
array=np.append(array,a3, axis=0)
array=np.append(array,a4, axis=0)
dfde007=pd.DataFrame(array)
print(dfde007)
df=pd.DataFrame(de014.item()['IR'].T[0]).transpose()
df['label']=1
sm=pd.DataFrame(de014.item()['OR'].T[0]).transpose()
sm['label']=1
sm1=pd.DataFrame(de014.item()['B'].T[0]).transpose()
sm1['label']=1
sm2=pd.DataFrame(de014.item()['Normal'].T[0]).transpose()
sm2['label']=0
a1=sm.values
a3=sm1.values
a4=sm2.values
a2=df.values
array=np.append(a1,a2, axis=0)
array=np.append(array,a3, axis=0)
array=np.append(array,a4, axis=0)
dfde014=pd.DataFrame(array)
print(dfde014)
df=pd.DataFrame(de021.item()['IR'].T[0]).transpose()
df['label']=1
sm=pd.DataFrame(de021.item()['OR'].T[0]).transpose()
sm['label']=1
sm1=pd.DataFrame(de021.item()['B'].T[0]).transpose()
sm1['label']=1
sm2=pd.DataFrame(de021.item()['Normal'].T[0]).transpose()
sm2['label']=0
a1=sm.values
a3=sm1.values
a4=sm2.values
a2=df.values
array=np.append(a1,a2, axis=0)
array=np.append(array,a3, axis=0)
array=np.append(array,a4, axis=0)
dfde021=pd.DataFrame(array)
print(dfde021)
df=pd.DataFrame(fe.item()['IR'].T[0]).transpose()
df['label']=1
sm=pd.DataFrame(fe.item()['OR'].T[0]).transpose()
sm['label']=1
sm1=pd.DataFrame(fe.item()['B'].T[0]).transpose()
sm1['label']=1
sm2=pd.DataFrame(fe.item()['Normal'].T[0]).transpose()
sm2['label']=0
a1=sm.values
a3=sm1.values
a4=sm2.values
a2=df.values
array=np.append(a1,a2, axis=0)
array=np.append(array,a3, axis=0)
array=np.append(array,a4, axis=0)
dffe=pd.DataFrame(array)
print(dffe)
df=pd.DataFrame(fe007.item()['IR'].T[0]).transpose()
df['label']=1
sm=pd.DataFrame(fe007.item()['OR'].T[0]).transpose()
sm['label']=1
sm1=pd.DataFrame(fe007.item()['B'].T[0]).transpose()
sm1['label']=1
sm2=pd.DataFrame(fe007.item()['Normal'].T[0]).transpose()
sm2['label']=0
a1=sm.values
a3=sm1.values
a4=sm2.values
a2=df.values
array=np.append(a1,a2, axis=0)
array=np.append(array,a3, axis=0)
array=np.append(array,a4, axis=0)
dffe007=pd.DataFrame(array)
print(dffe007)
df=pd.DataFrame(fe014.item()['IR'].T[0]).transpose()
df['label']=1
sm=pd.DataFrame(fe014.item()['OR'].T[0]).transpose()
sm['label']=1
sm1=pd.DataFrame(fe014.item()['B'].T[0]).transpose()
sm1['label']=1
sm2=pd.DataFrame(fe014.item()['Normal'].T[0]).transpose()
sm2['label']=0
a1=sm.values
a3=sm1.values
a4=sm2.values
a2=df.values
array=np.append(a1,a2, axis=0)
array=np.append(array,a3, axis=0)
array=np.append(array,a4, axis=0)
dffe014=pd.DataFrame(array)
print(dffe014)
df=pd.DataFrame(fe021.item()['IR'].T[0]).transpose()
df['label']=1
sm=pd.DataFrame(fe021.item()['OR'].T[0]).transpose()
sm['label']=1
sm1=pd.DataFrame(fe021.item()['B'].T[0]).transpose()
sm1['label']=1
sm2=pd.DataFrame(fe021.item()['Normal'].T[0]).transpose()
sm2['label']=0
a1=sm.values
a3=sm1.values
a4=sm2.values
a2=df.values
array=np.append(a1,a2, axis=0)
array=np.append(array,a3, axis=0)
array=np.append(array,a4, axis=0)
dffe021=pd.DataFrame(array)
print(dffe021)